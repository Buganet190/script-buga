package com.xsecurity.http;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.view.View;

import java.util.ArrayList;
import java.util.List;



/**************************************************\
 *                                                  *
 *                                                  *
 *                    @iPANDAX                      *
 *               @open_SRC_Projects                 *
 *                                                  *
 ***************************************************/

class ViewPagerAdapter extends FragmentPagerAdapter {

    private List<Fragment> mPages;
    private List<String> mTitles;

    ViewPagerAdapter(FragmentManager fm) {
        super(fm);

        mPages=new ArrayList<>();
        mTitles=new ArrayList<>();

    }

    void addFragment(Fragment page, String title)
    {
        mPages.add(page);
        mTitles.add(title);
    }

    @Override
    public Fragment getItem(int position) {
        return mPages.get(position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mTitles.get(position);
    }

    @Override
    public int getCount() {
        return mPages.size();
    }
}

