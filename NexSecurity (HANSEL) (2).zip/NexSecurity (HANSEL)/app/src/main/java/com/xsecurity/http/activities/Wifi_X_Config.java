
package com.xsecurity.http.activities;

import android.app.Activity;
import android.app.Notification.*;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import com.xsecurity.http.R;
import com.xsecurity.ultrasshservice.tunnel.TunnelUtils;
import android.text.Html;
import android.app.Notification;
import android.support.v7.widget.CardView;
import android.view.View.OnClickListener;
import android.view.View;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ToggleButton;
import android.widget.Button;
import pl.droidsonroids.gif.GifDrawable;
import pl.droidsonroids.gif.GifImageView;
import android.widget.ImageView;
import com.xsecurity.http.PanditaMainActivity;
import android.os.Vibrator;
import android.view.LayoutInflater;
import android.app.AlertDialog;
import android.view.Gravity;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Color;
import android.view.ViewGroup;
import android.os.Build;
import android.graphics.BitmapFactory;
import android.app.NotificationChannel;


/**************************************************\
 *                                                  *
 *                                                  *
 *                    @iPANDAX                      *
 *               @open_SRC_Projects                 *
 *                                                  *
 ***************************************************/



public class Wifi_X_Config extends AppCompatActivity implements ServiceConnection,
		OnCheckedChangeListener {
			
			
			
	public static final String TAG = "Wifi_X_Config";
	protected static final String KEY_PREFS = "proxy_pref";
	protected static final String KEY_ENABALE = "proxy_enable";
	private static int NOTIFICATION_ID = 20140701;
	private static final String PortDefault = "8080";
	private IWifi_X_Control proxyControl = null;
	private TextView tvInfo;
	private ToggleButton cbEnable;
	private Button ZonaWifi;
	private TextView txtip;
	private TextView text_port;
    private ImageView wifion;
    private ImageView wifioff;
    private TextView ipx;
    
    
  
    
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.proxy_settings);
		
		
		
	 Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar_main);
		setSupportActionBar(mToolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true); 
		

		tvInfo = (TextView) findViewById(R.id.tv_info);
		cbEnable = (ToggleButton) findViewById(R.id.cb_enable);
		cbEnable.setOnCheckedChangeListener(this);
		ipx = (TextView) findViewById(R.id.ip_layoutx);
      	ipx.setText(TunnelUtils.getLocalIpAddress());
        
        
        
        
        
        
        
        wifion = (ImageView) findViewById(R.id.conwifi);
        wifioff = (ImageView) findViewById(R.id.sinwifi);
		text_port = (TextView) findViewById(R.id.textport);
		text_port.setText(PortDefault);
		ZonaWifi = (Button) findViewById(R.id.zonawifi);
		ZonaWifi.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {
				Intent tetherSettings = new Intent();
				tetherSettings.setClassName("com.android.settings", "com.android.settings.TetherSettings");
				startActivity(tetherSettings);
			}
		});

		Intent intent = new Intent(this, Wifi_X_Service.class);
		bindService(intent, this, Context.BIND_AUTO_CREATE);
	}

	@Override
	public void onServiceConnected(ComponentName cn, IBinder binder) {
		proxyControl = (IWifi_X_Control) binder;
		if (proxyControl != null) {
			updateProxy();
		}
	}

	@Override
	public void onServiceDisconnected(ComponentName cn) {
		proxyControl = null;
	}

	@Override
	protected void onDestroy() {
		unbindService(this);
		super.onDestroy();
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		SharedPreferences sp = getSharedPreferences(KEY_PREFS, MODE_PRIVATE);
		sp.edit().putBoolean(KEY_ENABALE, isChecked).commit();
		updateProxy();
	}

	private void updateProxy() {
		if (proxyControl == null) {
			return;
		}

		boolean isRunning = false;
		try {
			isRunning = proxyControl.isRunning();
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		boolean shouldRun = getSharedPreferences(KEY_PREFS, MODE_PRIVATE)
				.getBoolean(KEY_ENABALE, false);
		if (shouldRun && !isRunning) {
			startProxy();
		} else if (!shouldRun && isRunning) {
			stopProxy();
		}

		try {
			isRunning = proxyControl.isRunning();
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		if (isRunning) {
			tvInfo.setText(R.string.proxy_on);
			cbEnable.setChecked(true);
			// Toast.makeText(this, "Wifi Sharet Desactivado", Toast.LENGTH_SHORT).show();
			
            wifioff.setVisibility(View.GONE);
            wifion.setVisibility(View.VISIBLE);
		} else {
			tvInfo.setText(R.string.proxy_off);
			cbEnable.setChecked(false);
			
			}
			}
			
			/// Toast.makeText(this, "Wifi Sharet Activo", Toast.LENGTH_SHORT).show();
		/**	LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View inflate = inflater.inflate(R.layout.wifi_desconectado, (ViewGroup) null);
            AlertDialog.Builder builer = new AlertDialog.Builder(this); 
            builer.setView(inflate); 
            //  ImageView iv = inflate.findViewById(R.id.icon);
            TextView title = inflate.findViewById(R.id.titulo);
            // TextView ms = inflate.findViewById(R.id.message);
            ImageView bubu = inflate.findViewById(R.id.afuera);
            // iv.setImageResource(R.drawable.src_images_mine_shareicon);
            title.setText("Wi-Fi Shared Desactivado, Activalo para compartir wifi.");
            // ms.setText("Ocurrio un error al buscar la actualizacion.\nPor favor contacta al desarrollador.");
            // bubu.setText("Ok");
            
            final AlertDialog alert = builer.create(); 
            alert.setCanceledOnTouchOutside(false);
            alert.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            alert.getWindow().setGravity(Gravity.CENTER); 
            alert.getWindow().getAttributes().windowAnimations = R.style.dialog;
            alert.show();
            bubu.setOnClickListener(new View.OnClickListener() { 
                    @Override 
                    public void onClick(View v) { 
                        try
                        {
                            alert.dismiss();

                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }

                    }});

            alert.show();
            
            wifioff.setVisibility(View.VISIBLE);
            wifion.setVisibility(View.GONE);
		} **/
	
    
    
    
    

	private void startProxy() {
		boolean started = false;
		try {
			started = proxyControl.start();
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		if (!started) {
			return;
		}

		NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

		Context context = getApplicationContext();

		Notification notification = new Notification();
		notification.icon = R.drawable.app;
		notification.tickerText = getResources().getString(R.string.proxy_on);
		notification.when = System.currentTimeMillis();
		nueva();
		CharSequence contentTitle = getResources().getString(R.string.app_name);
		;
		CharSequence contentText = getResources().getString(
				R.string.service_text);
		Intent intent = new Intent(this, Wifi_X_Service.class);
		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
				intent, 0);

		/*notification.setLatestEventInfo(context, contentTitle, contentText,
				pendingIntent);*/
		NotificationManager (context, contentTitle, contentText, pendingIntent);
		
		notification.flags |= Notification.FLAG_ONGOING_EVENT;

		manager.notify(NOTIFICATION_ID, notification);
		
		Vibrator vb_service = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
		vb_service.vibrate(10);
		Toast.makeText(this, getResources().getString(R.string.proxy_started),
				Toast.LENGTH_SHORT).show();
				
			}
      /**  LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View inflate = inflater.inflate(R.layout.wifi_conectado, (ViewGroup) null);
        AlertDialog.Builder builer = new AlertDialog.Builder(this); 
        builer.setView(inflate); 
		TextView port = inflate.findViewById(R.id.port);
		port.setText(PortDefault);
		
		TextView ippro= inflate.findViewById(R.id.ippro);
      	ippro.setText(TunnelUtils.getLocalIpAddress());
		
        TextView title = inflate.findViewById(R.id.activos);
        
        ImageView bubu = inflate.findViewById(R.id.afuerax2);
    
        
        title.setText("Asegurece De Tener La Zona-Wifi O Anclaje Encendido Para Que Esta Funcion Funcione Correctamente.");
       
        final AlertDialog alert = builer.create(); 
        alert.setCanceledOnTouchOutside(false);
        alert.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alert.getWindow().setGravity(Gravity.CENTER); 
        alert.getWindow().getAttributes().windowAnimations = R.style.dialog;
        alert.show();
        bubu.setOnClickListener(new View.OnClickListener() { 
                @Override 
                public void onClick(View v) { 
                    try
                    {
                        alert.dismiss();

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                }});

        alert.show();
        
                
	} **/

	
	
	private void nueva(){

		NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE); 
		Notification.Builder notification = new Notification.Builder(this);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			notification.setChannelId(this.getPackageName() + ".pandanexx");
			createNotification(notificationManager, this.getPackageName() + ".pandanexx");
		}

		notification.setContentTitle("Wifi Compartido")
			.setContentText("Wifi Sharet - Activo")
			
			.setDefaults(Notification.DEFAULT_ALL)
			.setPriority(Notification.PRIORITY_HIGH)
			//  .setOnlyAlertOnce(true)
		.setOngoing(true)
			.setShowWhen(false)
			.setUsesChronometer(true)
			.setSmallIcon(R.drawable.app);

		notificationManager.notify(1,notification.getNotification());
	}

	private void createNotification(NotificationManager notificationManager, String id)
	{
		NotificationChannel mNotif = new NotificationChannel(id, "Desarrollador", NotificationManager.IMPORTANCE_HIGH);
		mNotif.setShowBadge(false);
		notificationManager.createNotificationChannel(mNotif);
		// TODO: Implement this method
	}  
	
	
	private void nueva2(){

		NotificationManager notificationManager2 = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE); 
		Notification.Builder notification = new Notification.Builder(this);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			notification.setChannelId(this.getPackageName() + ".pandanexx");
			createNotification2(notificationManager2, this.getPackageName() + ".pandanexx");
		}

		notification.setContentTitle("Wifi Compartido")
			.setContentText("Wifi Sharet - Desactivado")

			.setDefaults(Notification.DEFAULT_ALL)
			.setPriority(Notification.PRIORITY_HIGH)
			.setShowWhen(false)
		
			
			.setSmallIcon(R.drawable.desactivado);

		notificationManager2.notify(1,notification.getNotification());
	}

	private void createNotification2(NotificationManager notificationManager, String id)
	{
		NotificationChannel mNotif = new NotificationChannel(id, "Desarrollador", NotificationManager.IMPORTANCE_HIGH);
		mNotif.setShowBadge(false);
		notificationManager.createNotificationChannel(mNotif);
		// TODO: Implement this method
	}  
	
	
	
	
	
	private void NotificationManager(Context context, CharSequence contentTitle, CharSequence contentText, PendingIntent pendingIntent) {
	}

	private void stopProxy() {
		boolean stopped = false;

		try {
			stopped = proxyControl.stop();
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		if (!stopped) {
			return;
		}

		tvInfo.setText(R.string.proxy_off);
		NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		manager.cancel(NOTIFICATION_ID);
		Vibrator vb_service = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
		vb_service.vibrate(10);
		nueva2();
		Toast.makeText(this, getResources().getString(R.string.proxy_stopped),
				Toast.LENGTH_SHORT).show();
                
                
        
	
                
                
	}
}
