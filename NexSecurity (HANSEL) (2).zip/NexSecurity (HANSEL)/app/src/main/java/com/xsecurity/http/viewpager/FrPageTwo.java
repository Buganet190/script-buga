package com.xsecurity.http.viewpager;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.xsecurity.http.R;



/**************************************************\
 *                                                  *
 *                                                  *
 *                    @iPANDAX                      *
 *               @open_SRC_Projects                 *
 *                                                  *
 ***************************************************/


public class FrPageTwo extends Fragment {


    public FrPageTwo() {
        // Required empty public constructor FrPageTwo new context;
    }

    public static FrPageTwo newInstance() {

        Bundle args = new Bundle();

        FrPageTwo fragment = new FrPageTwo();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        
        return inflater.inflate(R.layout.app_intro2, container, false);
    }

}
