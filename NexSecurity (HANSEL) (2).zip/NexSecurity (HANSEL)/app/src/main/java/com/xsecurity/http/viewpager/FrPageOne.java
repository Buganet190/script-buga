package com.xsecurity.http.viewpager;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.xsecurity.http.R;


/**************************************************\
 *                                                  *
 *                                                  *
 *                    @iPANDAX                      *
 *               @open_SRC_Projects                 *
 *                                                  *
 ***************************************************/


public class FrPageOne extends Fragment {


    public FrPageOne() {
        // Required empty public constructor
    }

    public static FrPageOne newInstance() {
        
        Bundle args = new Bundle();
        
        FrPageOne fragment = new FrPageOne();
        fragment.setArguments(args);
        return fragment;
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.app_intro1, container, false);
    }

}
