package com.xsecurity.http;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import com.xsecurity.http.R;
import com.xsecurity.http.PanditaMainActivity;
import com.xsecurity.http.ViewPagerAdapter;
import com.xsecurity.http.viewpager.FrPageThree;
import com.xsecurity.http.viewpager.FrPageTwo;
import com.xsecurity.http.viewpager.FrPageOne;
import android.os.Vibrator;
import android.content.Context;

/**************************************************\
 *                                                  *
 *                                                  *
 *                    @iPANDAX                      *
 *               @open_SRC_Projects                 *
 *                                                  *
 ***************************************************/

public class ViewpagerActivity extends AppCompatActivity {

    private ViewPager mViewPager;
    public Animation animFadeIn, animFadeOut;
    private ViewPagerAdapter mAdapter;
	public View back;
	public View next;
    public View ok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewpagersplash);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { 
            View view = getWindow().getDecorView();

            getWindow().setNavigationBarColor(getResources().getColor(R.color.white));
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        
        
		
		next = (View) findViewById(R.id.nextt);
		ok = (View) findViewById(R.id.ok);
        
        mAdapter=new ViewPagerAdapter(getSupportFragmentManager());
        mAdapter.addFragment(FrPageOne.newInstance(),getResources().getString(R.string.fr_1));
        mAdapter.addFragment(FrPageTwo.newInstance(),getResources().getString(R.string.fr_2));
        mAdapter.addFragment(FrPageThree.newInstance(),getResources().getString(R.string.fr_3));

		mViewPager = (ViewPager) findViewById(R.id.view_pager);
		mViewPager.setAdapter(mAdapter);     
		mViewPager.setCurrentItem(0);
     
      //  back.setVisibility(View.GONE);
        ok.setVisibility(View.GONE);
        next.setVisibility(View.VISIBLE);
        
        coloreazul();
        
        /******************************************************************
         Allnet moder: CLICK PAGE BACK
         ********************************************************************/
	/**	back.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					// Do something in response to button click
					Vibrator vb_service = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
					vb_service.vibrate(10);
					mViewPager.setCurrentItem(mViewPager.getCurrentItem() - 1);
					animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
					back.startAnimation(animFadeOut);
                    

                    if(mViewPager.getCurrentItem() == 0)
                    {
                        coloreazul();
                        back.setVisibility(View.GONE);
                        ok.setVisibility(View.GONE);
                        next.setVisibility(View.VISIBLE);
                    }
                    if(mViewPager.getCurrentItem() == 1)
                    {
                        colorred();
                        ok.setVisibility(View.GONE);
                        back.setVisibility(View.GONE);
                        next.setVisibility(View.VISIBLE);
                    }
                    if(mViewPager.getCurrentItem() == 2)
                    {
                        colorgreen();
                        back.setVisibility(View.GONE);
                        next.setVisibility(View.GONE);
                        ok.setVisibility(View.VISIBLE);
                    }
                    
                    
				}
			});

**/
        /******************************************************************
         Allnet moder: CLICK PAGE NEXT
         ********************************************************************/
		next.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					// Do something in response to button click
					mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
					Vibrator vb_service = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
					vb_service.vibrate(10);
				//	animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
					// next.startAnimation(animFadeOut);
			   
                    if(mViewPager.getCurrentItem() == 0)
                    {
                        coloreazul();
                       // back.setVisibility(View.GONE);
                        ok.setVisibility(View.GONE);
                        next.setVisibility(View.VISIBLE);
                    }
                    if(mViewPager.getCurrentItem() == 1)
                    {
                        colorred();
                        ok.setVisibility(View.GONE);
                     //   back.setVisibility(View.GONE);
                        next.setVisibility(View.VISIBLE);
                    }
                    if(mViewPager.getCurrentItem() == 2)
                    {
                        colorgreen();
                       // back.setVisibility(View.GONE);
                        next.setVisibility(View.GONE);
                        ok.setVisibility(View.VISIBLE);
                    }
                        
				}
			});
            

        /******************************************************************
         Allnet moder: CLICK PAGE OK
         ********************************************************************/
        ok.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    // Do something in response to button click
					Vibrator vb_service = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
					vb_service.vibrate(10);
                  //  animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
                  //  ok.startAnimation(animFadeOut);
                    
                    Intent intentfirst = new Intent(ViewpagerActivity.this, PanditaMainActivity.class);
                    startActivity(intentfirst);
                    overridePendingTransition(R.anim.up_enter,R.anim.up_exit);

                }
            });
		
            
        /******************************************************************
         Allnet moder: PAGINAS VIEW
         ********************************************************************/   
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int arg0, float arg1, int arg2) {
                    // TODO Auto-generated method stub


                } 
                    public void onPageSelected(int arg0) {
                    // TODO Auto-generated method stub
                    if(mViewPager.getCurrentItem() == 0)
                    {

                        coloreazul();
                      //  back.setVisibility(View.GONE);
                        ok.setVisibility(View.GONE);
                        next.setVisibility(View.VISIBLE);
                      //  animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                    //    next.startAnimation(animFadeIn);

                    }
                    if(mViewPager.getCurrentItem() == 1)
                    {
                        colorred();
                        ok.setVisibility(View.GONE);
                      //  back.setVisibility(View.GONE);
                        next.setVisibility(View.VISIBLE);
                     //   animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                      //  back.startAnimation(animFadeIn);
                    //    animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                      //  next.startAnimation(animFadeIn);
                    }
                    if(mViewPager.getCurrentItem() == 2)
                    {
                        colorgreen();
                       // back.setVisibility(View.GONE);
                        next.setVisibility(View.GONE);
                        ok.setVisibility(View.VISIBLE);
                   //     animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                       // ok.startAnimation(animFadeIn);
                    }
                }

          public void onPageScrollStateChanged(int arg0) {
                    // TODO Auto-generated method stub
                    
                    
      /***        if(mViewPager.getCurrentItem() == 0)
              {

                  coloreazul();
                  back.setVisibility(View.GONE);
                  ok.setVisibility(View.GONE);
                  next.setVisibility(View.VISIBLE);
                  animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                  next.startAnimation(animFadeIn);

              }
              if(mViewPager.getCurrentItem() == 1)
              {
                  colorred();
                  ok.setVisibility(View.GONE);
                  back.setVisibility(View.VISIBLE);
                  next.setVisibility(View.VISIBLE);
                  animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                  back.startAnimation(animFadeIn);
                  animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                  next.startAnimation(animFadeIn);
              }
              if(mViewPager.getCurrentItem() == 2)
              {
                  colorgreen();
                  back.setVisibility(View.VISIBLE);
                  next.setVisibility(View.GONE);
                  ok.setVisibility(View.VISIBLE);
                  animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
                  ok.startAnimation(animFadeIn);
              } ***/

                  }   
              });

  
              
         /******************************************************************
         Allnet moder: PAGINAS VIEW
         ********************************************************************/
         
	       }
    
	public void coloreazul(){    

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { 
            View view = getWindow().getDecorView();

            getWindow().setNavigationBarColor(getResources().getColor(R.color.blue));
            getWindow().setStatusBarColor(getResources().getColor(R.color.blue));
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }
    public void colorred(){

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { 
            View view = getWindow().getDecorView();

            getWindow().setNavigationBarColor(getResources().getColor(R.color.blue));
            getWindow().setStatusBarColor(getResources().getColor(R.color.blue));
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }
    public void colorgreen(){

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { 
            View view = getWindow().getDecorView();

            getWindow().setNavigationBarColor(getResources().getColor(R.color.green));
            getWindow().setStatusBarColor(getResources().getColor(R.color.green));
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }
    
	@Override
	public void onBackPressed() {
		if (mViewPager.getCurrentItem() == 0) {
			
			// If the user is currently looking at the first step, allow the system to handle the
			// Back button. This calls finish() on this activity and pops the back stack.
			super.onBackPressed();
		} else {
			// Otherwise, select the previous step.
			mViewPager.setCurrentItem(mViewPager.getCurrentItem() - 1);
		
			
			if(mViewPager.getCurrentItem() == 0)
			{
				back.setVisibility(View.GONE);
				}
		}
	}

}
	
