package com.xsecurity.http.activities;

import com.xsecurity.http.core.ProxyServer;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;


/**************************************************\
 *                                                  *
 *                                                  *
 *                    @iPANDAX                      *
 *               @open_SRC_Projects                 *
 *                                                  *
 ***************************************************/


public class Wifi_X_Service extends Service {
	public static final String TAG = "Wifi_X_Service";

	@Override
	public IBinder onBind(Intent binder) {
		return new IWifi_X_Control.Stub() {
			@Override
			public boolean start() throws RemoteException {
				return doStart();
			}

			@Override
			public boolean stop() throws RemoteException {
				return doStop();
			}

			@Override
			public boolean isRunning() throws RemoteException {
				return ProxyServer.getInstance().isRunning();
			}

			@Override
			public int getPort() throws RemoteException {
				return ProxyServer.getInstance().getPort();
			}

		};
	}

	@Override
	public void onCreate() {
		super.onCreate();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

	private boolean doStart() {
		ProxyServer proxyServer = ProxyServer.getInstance();
		if (proxyServer.isRunning()) {
			return false;
		}

		return proxyServer.start();
	}

	private boolean doStop() {
		ProxyServer proxyServer = ProxyServer.getInstance();
		if (!proxyServer.isRunning()) {
			return false;
		}

		return proxyServer.stop();
	}

}
