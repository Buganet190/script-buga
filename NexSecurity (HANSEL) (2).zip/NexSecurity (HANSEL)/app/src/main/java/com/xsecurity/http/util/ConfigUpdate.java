package com.xsecurity.http.util;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.app.ProgressDialog;



import org.json.JSONException;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import cn.pedant.SweetAlert.widget.SweetAlertDialog;

import android.graphics.Color;
import cn.pedant.SweetAlert.widget.SweetAlertDialog;
import com.xsecurity.compatstyle.R;

public class ConfigUpdate extends AsyncTask<String, String, String> {

    private Context context;
    private OnUpdateListener listener;
    private ProgressDialog progressDialog;
    private boolean isOnCreate;
	
	/**************************************************\
	 *                                                  *
	 *                                                  *
	 *                    @iPANDAX                      *
	 *               @open_SRC_Projects                 *
	 *                                                  *
	 ***************************************************/
	
	

	private String update = new String(new byte[]{104,116,116,112,115,58,47,47,98,105,116,98,105,110,46,105,116,47,86,57,69,117,97,103,119,108,47,114,97,119,47,});

	
    
    public ConfigUpdate(Context context, OnUpdateListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void start(boolean isOnCreate) {
        this.isOnCreate = isOnCreate;
        execute();
    }

    public interface OnUpdateListener {
        void onUpdateListener(String result);
    }

    @Override
    protected String doInBackground(String... strings) {
        try {
            StringBuilder sb = new StringBuilder();
            URL url = new URL(update);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String response;

            while ((response = br.readLine()) != null) {
                sb.append(response);
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "Error on getting data:  " + e.getMessage();
        }
    }

	
	
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
       if (!isOnCreate) {
		   
		   
   //HANSEL & PRIMAS \\
   progressDialog = new ProgressDialog(context, 4);
   progressDialog.setCanceledOnTouchOutside(true);
   progressDialog.show();
   progressDialog.setContentView(R.layout.buscando_actualizacion);
   progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
   progressDialog.getWindow().getAttributes().windowAnimations = R.style.dialog;
   
       }
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        if (!isOnCreate && progressDialog != null) {
            progressDialog.dismiss();
        }
        if (listener != null) {
            listener.onUpdateListener(s);
        }
    }
}
