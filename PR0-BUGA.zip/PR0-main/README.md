# BEM VINDO 🖕

# SSH-PLUS

# @buganetiptv

*PROJETO EM ANDAMENTO...


# Modo de instalação
# 👇👽👍
Só joga na máquina e deixar instalar

• atualiza sistema

• desativa Ipv6

• instala recursos e o script
```
apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/TH30R10N/PR0/main/ssh-plus)

```
